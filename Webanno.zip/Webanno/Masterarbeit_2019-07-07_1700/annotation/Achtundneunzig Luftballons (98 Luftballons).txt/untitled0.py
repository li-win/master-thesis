# -*- coding: utf-8 -*-
"""
Created on Sun Jul  7 19:42:19 2019
Python 3.7
@author: Lisa Winkler
"""

import csv
import pandas as pd
import numpy as np

liste = []
with open('admin.tsv', encoding='utf-8') as tsvfile:
    reader = csv.reader(tsvfile, delimiter='\t')
    for row in reader:
        liste.append(row)

#del liste[0:4]      
#print(liste[:30])
print(len(liste))

dfObj = pd.DataFrame(liste)
print(dfObj.head(3))
export_excel = dfObj.to_excel (r'test.xlsx', index = None, header=False)